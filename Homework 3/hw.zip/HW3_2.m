stim = double(stim);
counts = double(counts);
dimensions = size(stim);
t_max = dimensions(3);
pause('on')
spike_avg_arr = zeros(16,16,12);

% Start at 13 so previous 12 frames can be accessed
for i = 13:t_max
    % THIS VARIABLE NOT USED IN 2ND VERSION
    %spike_avg = zeros(16,16);
    
    % determines if there is a spike
    if (counts(i) > 0)
        
        % METHOD I
        % adds weighted previous frames to corresponding bin (of 12)
        for t = 1:12
            spikes = counts(i-t);
            weighted = stim(:,:,i-t)*counts(i);
            % very different result when using counts(i) instead of spikes,
            % above
            spike_avg_arr(:,:,13-t) = spike_avg_arr(:,:,13-t) + weighted;
            
        end
        
        % METHOD II
        % creates and displays an average for each frame with a spike, of
        % the previous 12 frames.
        
        %for t = (i-12):(i-1)
            %spikes = counts(t);
            %weighted = stim(:,:,t)*spikes;
            %spike_avg = spike_avg + weighted;
        %end
        
        %spike_avg = spike_avg/12;
        
        %figure(1);
        %imagesc(spike_avg);
        %pause(0.005);
        
    end
end

% METHOD 1 cont
% Averages the 12 bins by total number of spikes and displays them
spike_avg_arr = spike_avg_arr/sum(counts);
for i = 1:12
    figure(1);
    imagesc(spike_avg_arr(:,:,i));
    pause(1);
end

%for j = 1:16
%    image = zeros(12,16);
%    for i = 1:12
%        image(i, :) = spike_avg_arr(j, :, i);
%    end
%    figure(i+1);
%    imagesc(image)
%    pause(1);
%end

image = zeros(12,16);
for i = 1:12
    for j = 1:16
        image(i, :) = image(i,:) + spike_avg_arr(j, :, i);
    end
end

figure(2)
imagesc(image)
