function [ ] = HW3_2_func( stim, counts )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
    dimensions = size(stim);
    t_max = dimensions(3);
    stim = double(stim);
    counts = double(counts);

    for i = 1:t_max
        spike_avg = zeros(16,16);
        % determines if there is a spike
        if (counts(i) > 0)
            % determines how many to average
            if (i < 13 && i > 1)
                prev = i - 1;
            else
                prev = 12;
            end

            for t = (i-prev):(i-1)
                spikes = counts(t);
                weighted = stim(:,:,t)*spikes;
                spike_avg = spike_avg + stim(:,:,t);
            end

            spike_avg = spike_avg/prev;

            figure(1);
            imagesc(spike_avg);
        end
    end

end

