sample_rate = 1000;
dt = 1/sample_rate;
time = 0.1;
T = 100;

x=100;
i=1;
j=0;
delay1 = 1;

figure;hold;

for delay2=delay1:1:x;
    j=j+1;
    x1 = zeros(1,x);x1(delay1) = 1;
    x2 = zeros(1,x);x2(delay2) = 1;
    
    if (delay1==delay2);
        xs= zeros(1,x); xs(delay1) = 2;
    else
        xs = zeros(1,x); xs(delay1)=1; xs(delay2)=1;
    end
    
    y1 = NCE_Hw3_2015(x1);
    y2 = NCE_Hw3_2015(x2);
    ys = NCE_Hw3_2015(xs);
    
    h = (ys-y2-y1)/2;
    
    T1 = delay2:1:x;
    T2 = T1+(delay1-delay2);
    h = h(delay2:length(h));
    disp(h)
    plot3(T1, T2, h)
end

axis([0 T 0 T])
view (100,50)